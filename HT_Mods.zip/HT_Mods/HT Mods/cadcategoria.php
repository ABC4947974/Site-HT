<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova categoria</title>
    <style>
        #container-formulario {
            width: 500px;
            margin: auto;
            top: 5vh;
            position: relative;
        }

        #botao {
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <?php
    include_once('./header_paineladm.php');
    session_start();
    if (!isset($_SESSION["admin-ativo"])) {
        header("Location: ./admin-ht.php");
    }
    ?>
    <div id="container-formulario">
        <div id="titulo">
            <h1>Criar nova categoria</h1>
        </div>
        <div id="formulario">
            <form action="./controller/insereCategoria.php" method="POST">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Nome da categoria: </label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" autofocus required name="nome-categoria">
                </div>
                <select class="form-select" aria-label="Default select example" required name="tipo-categoria">
                    <option selected>Tipo de mod</option>
                    <option value="c">Computador</option>
                    <option value="m">Mobile</option>
                </select>
                <div id="botao">
                    <button type="submit" class="btn btn-success">Criar</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
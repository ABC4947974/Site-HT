<?php
    $hostname = "localhost";
    $user = "root";
    $password = "";
    $database = "banco_htmods";

    $connect = mysqli_connect($hostname, $user, $password, $database);

?>
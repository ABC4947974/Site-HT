<?php
    include_once("./conexao.php");
    session_start();
    if(!isset($_POST["usuario"]) || !isset($_POST["senha"])){
        header("Location: ../admin-ht.php");
    }
    else{
        if(isset($_SESSION["admin-ativo"])){
            header("Location: ../paineladm.php");
        }
        else{
            $usuario = $_POST["usuario"];
            $senha = $_POST["senha"];
    
            $query_busca_login = "SELECT usuario_adm, senha_adm FROM tb_admin 
            WHERE usuario_adm = '$usuario' AND senha_adm = '$senha'";
    
            $result_busca = mysqli_query($connect, $query_busca_login);
            $total = mysqli_num_rows($result_busca);
    
            if($total === 0){
                header("Location: ../admin-ht.php");
            }
            else{
                session_start();
                $_SESSION["admin-ativo"] = $senha;
                header("Location: ../paineladm.php");
            }
        }
    }

?>
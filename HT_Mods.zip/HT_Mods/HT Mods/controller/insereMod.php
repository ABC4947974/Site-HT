<title>Inserindo mod</title>
<h3>Aguarde...</h3>
<?php
    include_once('./conexao.php');

    if(!isset($_POST["nome"])){
        header("Location: ../cadMod.php");
    }
    else{
        $nome_mod = $_POST["nome"];
        $descricao = $_POST["descricao"];
        $autor = $_POST["autor"];
        $download = $_POST["download"];
        $imagem = $_POST["imagem"];
        $categoria = $_POST["categoria"];
        $imagem_1 = $_POST["imagem_1"];
        $imagem_2 = $_POST["imagem_2"];
        $imagem_3 = $_POST["imagem_3"];

        $busca_cod_categoria = "SELECT cod_categoria FROM tb_categorias WHERE cod_categoria = '$categoria'";
        $result_cod = mysqli_query($connect, $busca_cod_categoria);
        $dados_categoria = mysqli_fetch_assoc($result_cod);
        $codigo = $dados_categoria["cod_categoria"];
        echo $codigo;

        $query_insert_mod = "INSERT INTO tb_mods(cod_mod, nome_mod, descricao_mod, autor, link_donwload, link_imagem, cod_categoria, imagem1, imagem2, imagem3)
        VALUES(default, '$nome_mod', '$descricao', '$autor', '$download', '$imagem', $codigo, '$imagem_1', '$imagem_2', '$imagem_3')";
        $execute_insert = mysqli_query($connect, $query_insert_mod);
        header("Location: ../paineladm.php");

    }

?>
<title>Deletando categoria</title>
<h2>Aguarde...</h2>
<?php
include_once('./conexao.php');
if (!isset($_POST["cod_categoria"])) {
    header("Location: ../deletecategoria.php");
} else {
}
$codigo = $_POST["cod_categoria"];
$query_deleta_categoria = "DELETE FROM tb_categorias WHERE cod_categoria = $codigo";
$query_deleta_mod = "DELETE FROM tb_mods WHERE cod_categoria = $codigo";
$result_delete = mysqli_query($connect, $query_deleta_categoria);
$result_delete_mod = mysqli_query($connect, $query_deleta_mod);

header("Location: ../deletecategoria.php");
?>
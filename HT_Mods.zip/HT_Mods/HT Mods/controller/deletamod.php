<title>Deletando mod</title>
<h2>Aguarde...</h2>
<?php
    include_once('./conexao.php');

    if(!isset($_POST['cod_mod']))
    {
        header("Location: ../deletemod.php");
    }
    else{
        $codigo = $_POST["cod_mod"];
        $query = "DELETE from tb_mods where cod_mod = $codigo";
        $execute = mysqli_query($connect, $query);

        header("Location: ../paineladm.php");
    }

?>
<title>Atualizando mod...</title>
<h2>Aguarde...</h2>
<?php
    include_once('./conexao.php');

    if(!isset($_POST["nome"]) || !isset($_POST["descricao"])){
        header("Location: ../configmod.php");
    }
    else{
        $cod_mod = $_POST["cod_mod"];
        $nome = $_POST["nome"];
        $descricao = $_POST["descricao"];
        $autor = $_POST["autor"];
        $download = $_POST["download"];
        $imagem = $_POST["categoria"];
        $categoria = $_POST["categoria"];

        $query_atualiza = "UPDATE tb_mods
        set nome_mod = '$nome', descricao_mod = '$descricao', autor = '$autor', link_donwload = '$download', 
        link_imagem = '$imagem', cod_categoria = $categoria where cod_mod = $cod_mod";

        $executa_atualizacao = mysqli_query($connect, $query_atualiza);
        header("Location: ../paineladm.php");
    }
?>
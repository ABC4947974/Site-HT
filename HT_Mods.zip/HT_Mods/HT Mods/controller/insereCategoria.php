<?php
    include_once('./conexao.php');

    if(!isset($_POST["nome-categoria"]))
        header("Location: ../cadcategoria.php");
    else{
        $nome_categoria = $_POST["nome-categoria"];
        $tipo_categoria = $_POST["tipo-categoria"];

        //busca se ja existe
        $query_busca = "SELECT cod_categoria FROM tb_categorias WHERE nome_categoria = '$nome_categoria'";
        $result_busca = mysqli_query($connect, $query_busca);

        if(mysqli_num_rows($result_busca) > 0){
            session_start();
            $_SESSION["erro_cria_categoria"] = "Categoria '". $nome_categoria ."' JA EXISTE NO SISTEMA!";
            header("Location: ../cadcategoria.php");
        }
        else{
            $query_insert_categoria = "INSERT INTO tb_categorias(cod_categoria, nome_categoria, tipo_categoria) 
            VALUES(default, '$nome_categoria', '$tipo_categoria')";
    
            $result_insert = mysqli_query($connect, $query_insert_categoria);
            session_start();
            $_SESSION["sucesso_cria_categoria"] = "Categoria '". $nome_categoria ."' criada com sucesso!";
            header("Location: ../paineladm.php");
        }
    }
?>
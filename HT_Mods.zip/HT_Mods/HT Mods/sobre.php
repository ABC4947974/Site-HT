<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./img/icon.ico" type="image/x-icon">
    <link rel="stylesheet" href="estilos.css">
    <title>HT Mods | Sobre</title>
    <style>
        .texto-sobre {
            padding: 10px;
            font-size: 14pt;
        }
    </style>
</head>

<body onload="ano()">
    <nav>
        <div class="logo">HT MODS</div>
        <div class="botoes">
            <ul class="lista-menu">
                <li class="btn-list" onclick="document.location.href ='./index.php'">Computador</li>
                <li class="btn-list" onclick="document.location.href ='./mobile.php'">Mobile</li>
                <li class="btn-list" onclick="document.location.href ='./sobre.php'">Sobre</li>
                <li class="btn-list" onclick="document.location.href ='./comunidade.php'">Comunidade</li>
            </ul>
        </div>
        <div class="container-pesquisa">
            <form action="./buscar.php" method="GET">
                <input type="text" name="caixa-busca" id="" class="caixa-busca-mod" placeholder="Buscar mod" required>
                <button class="btn-procurar" type="submit">Procurar</button>
            </form>
        </div>
    </nav>
    <header>
        <div class="container-header">
            <h1>Sobre a HT Mods</h1>
            <p class="texto-sobre">
                A HunterS (HT) é um clan de SAMP criado em maio de 2021 pelo player Se7en. Em 2022, foi descidido criar uma extensão do clan para o desenvolvimento de mods para o GTA San Andreas. Atualmente, temos 154 membros no clan.
            </p>
        </div>
    </header>
    <footer>
        <div class="texto-rodape">
            <p id="txt-ano"></p>
        </div>
    </footer>
    <script>
        function ano() {
            var data = new Date()
            var ano = data.getFullYear()
            var texto = document.getElementById('txt-ano')
            texto.innerText = `HT Mods 2021 - ${ano}`
        }
    </script>
</body>

</html>
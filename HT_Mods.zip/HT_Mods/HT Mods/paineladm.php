<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <title>Painel de controle</title>
    <style>
        #container-geral {
            width: 600px;
            margin: auto;
            position: relative;
            top: 3vh;
        }

        #list-item-categoria {
            width: 598px;
            border: 1px solid rgb(0, 0, 0, 0.10);
            font-size: 16pt;
            padding: 10px;
            justify-content: space-between;
            margin: 2px;
        }

        .botao-mais {
            position: relative;
            float: right;
        }

        .input {
            border: none;
            outline: none;
            cursor: default;
        }
        .input-cod{
            border: none;
            outline: none;
            cursor: default;
            width: 50px;
        }
    </style>
</head>

<body>
    <?php
    include_once('./controller/conexao.php');
    session_start();
    if (!isset($_SESSION["admin-ativo"])) {
        header("Location: ./admin-ht.php");
    } else {
        $query_busca_categoria = "SELECT * FROM tb_categorias where tipo_categoria = 'c' order by nome_categoria";
        $result_busca_categoria = mysqli_query($connect, $query_busca_categoria);

        $query_mobile = "SELECT * FROM tb_categorias where tipo_categoria = 'm' order by nome_categoria";
        $result_query_mobile = mysqli_query($connect, $query_mobile);
    }
    ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Painel de Controle</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="./paineladm.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Ações
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="./cadcategoria.php">Criar categoria</a></li>
                            <li><a class="dropdown-item" href="./deletecategoria.php">Deletar Categoria</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="./cadmod.php">Publicar mod</a></li>
                            <li><a class="dropdown-item" href="./deletemod.php">Deletar mod</a></li>  
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="./controller/quit.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <main id="container-geral">
        <h1>Categorias</h1>
        <label for="">Código \ nome</label>
        <section>
            <details>
                <summary>Computador</summary>
                <?php
                foreach ($result_busca_categoria as $categoria) {
                ?>
                    <div id="list-item-categoria">
                        <form action="./detalhesCategoria.php" method="POST">
                            <input type="number" name="cod_categoria" id="codigo" value="<?= $categoria["cod_categoria"] ?>" class="input-cod" readonly="false">
                            <input type="text" name="nome_categoria" id="nome" value="<?= $categoria["nome_categoria"] ?>" class="input" readonly="false">
                            <button type="submit" class="btn btn-secondary botao-mais">Mais...</button>
                        </form>
                    </div>
                <?php
                }
                ?>
            </details>
        </section>
        <section>
            <details>
                <summary>Mobile</summary>
                <?php
                foreach ($result_query_mobile as $categoria_mobile) {
                ?>
                    <div id="list-item-categoria">
                        <form action="./detalhesCategoria.php" method="POST">
                            <input type="number" name="cod_categoria" id="codigo" value="<?= $categoria_mobile["cod_categoria"] ?>" class="input-cod" readonly="false">
                            <input type="text" name="nome_categoria" id="nome" value="<?= $categoria_mobile["nome_categoria"] ?>" class="input" readonly="false">
                            <button type="submit" class="btn btn-secondary botao-mais">Mais...</button>
                        </form>
                    </div>
                <?php
                }
                ?>
            </details>
        </section>
    </main>
</body>

</html>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="./img/icon.ico" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes categoria</title>
    <style>
        #container-geral {
            width: 600px;
            margin: auto;
            position: relative;
            top: 3vh;
        }

        #list-item-categoria {
            width: 598px;
            border: 1px solid rgb(0, 0, 0, 0.10);
            font-size: 16pt;
            padding: 10px;
            justify-content: space-between;
            margin: 2px;
        }

        .botao-mais {
            position: relative;
            float: right;
        }

        .input {
            border: none;
            outline: none;
            cursor: default;
            width: 350px;
        }

        .input-cod {
            border: none;
            outline: none;
            cursor: default;
            width: 50px;
        }
    </style>

</head>

<body>
    <?php
    include_once('./header_paineladm.php');
    include_once('./controller/conexao.php');
    session_start();
    if (!isset($_SESSION["admin-ativo"])) {
        header("Location: ./admin-ht.php");
    }
    else{      
        $cod_categoria = $_POST["cod_categoria"];
        $categoria = $_POST["nome_categoria"];
        $_SESSION["cod_categoria_pagDetalhes"] = $cod_categoria;
        $cod = $_SESSION["cod_categoria_pagDetalhes"];

        $lista_mods_categoria = "SELECT cod_mod, nome_mod, descricao_mod FROM tb_mods WHERE cod_categoria = $cod";
        $result_lista_mods = mysqli_query($connect, $lista_mods_categoria);
    }

    ?>
    <div id="container-geral">
        <h1>Lista de mods '<?= $categoria?>'</h1>
        <label for="">Código \ nome</label>
        <?php
        foreach ($result_lista_mods as $mod) {
        ?>
            <div id="list-item-categoria">
                <form action="./configmod.php" method="POST">
                    <input type="number" name="cod_mod" id="codigo" value="<?= $mod["cod_mod"] ?>" class="input-cod" readonly="false">
                    <input type="text" name="nome_mod" id="nome" value="<?= $mod["nome_mod"] ?>" class="input" readonly="false">
                    <button type="submit" class="btn btn-secondary botao-mais">Config</button>
                </form>
            </div>
        <?php
        }
        ?>
    </div>
</body>

</html>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./img/icon.ico" type="image/x-icon">
    <link rel="stylesheet" href="estilos.css">
    <title>HT Mods | Comunidade</title>
    <style>
        .texto-sobre {
            padding: 10px;
            font-size: 14pt;
        }

        #container-botoes-comunidade {
            max-width: max-content;
            margin: auto;
            position: relative;
            top: 5vh;
        }

        .bloco-comunidade {
            border: 3px solid rgba(0, 0, 0, 0.425);
            border-radius: 6px;
            width: 350px;
            font-size: 30pt;
            font-weight: bold;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-right: 30px;
            padding-left: 30px;
            margin-bottom: 20px;
            cursor: pointer;
            transition: all 0.4s;

        }

        .bloco-comunidade:hover {
            border-color: blue;
        }

        #icon-discord {
            background: url('./discord.png') no-repeat center center;
            background-size: cover;
        }
    </style>
</head>

<body onload="ano()">
    <nav>
        <div class="logo">HT MODS</div>
        <div class="botoes">
            <ul class="lista-menu">
                <li class="btn-list" onclick="document.location.href ='./index.php'">Computador</li>
                <li class="btn-list" onclick="document.location.href ='./mobile.php'">Mobile</li>
                <li class="btn-list" onclick="document.location.href ='./sobre.php'">Sobre</li>
                <li class="btn-list" onclick="document.location.href ='./comunidade.php'">Comunidade</li>
            </ul>
        </div>
        <div class="container-pesquisa">
            <form action="./buscar.php" method="GET">
                <input type="text" name="caixa-busca" id="" class="caixa-busca-mod" placeholder="Buscar mod" required>
                <button class="btn-procurar" type="submit">Procurar</button>
            </form>
        </div>
    </nav>
    <header>
        <div class="container-header">
            <h1>Comunidade</h1>
            <div id="container-botoes-comunidade">
                <div class="bloco-comunidade" onclick="document.location.href = 'https://discord.gg/ZJGyFeszQf'">
                    <div class="nome-comunidade">HT Mods</div>
                    <img src="./img/discord.png" alt="" width="50" height="50">
                </div>
                <div class="bloco-comunidade">
                    <div class="nome-comunidade" onclick="alert('Instagram ainda nao foi criado :)')">Instagram</div>
                    <img src="./img/Instagram.png" alt="" width="50" height="50">
                </div>
                <div class="bloco-comunidade" onclick="alert('Canal do youtube ainda nao foi criado :)')">
                    <div class="nome-comunidade">Youtube</div>
                    <img src="./img/youtube.png" alt="" width="50" height="50">
                </div>
            </div>
        </div>
    </header>
</body>

</html>
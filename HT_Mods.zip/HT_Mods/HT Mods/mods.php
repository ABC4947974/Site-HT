<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./img/icon.ico" type="image/x-icon">
    <link rel="stylesheet" href="estilos.css">
    <title>HT Mods </title>
    <style>

        .container-lista-card{
            position: relative;
            width: 1000px;
            margin-left: 100px;
            top: 5vh;
            margin: auto;
        }
        #icon-discord {
            background: url('./discord.png') no-repeat center center;
            background-size: cover;
        }
        .card-mod{
            border: 1px solid rgba(0, 0, 0, 0.125);
            border-radius: 0px;
            margin-top: 20px;
            width: 280px;
            margin-right: 20px;
            padding-bottom: 10px;
        }
        .lista-card{
            list-style: none;
        }
        .linha-card{
            display: inline-block;
        }
        .linha-card:hover{
            cursor: default;
            color: black;
        }
        .titulo-card{
            text-align: center;
            margin: 10px;
            height: 90px;
        }
        .descricao-card{
            text-align: center;
            padding: 10px;
        }
        .imagem-card{
            background-color: #8a8a8a;
            width: 280px;
            height: 200px;
        }
        .bloco-info{
            width: 100%;
            justify-content: space-between;
        }
        .bloco-botao-detalhes{
            text-align: center;
        }
        .botao-baixar{
            width: 100px;
            padding: 10px;
            font-weight: bold;
            border: 1px solid rgba(0, 0, 0, 0.125);
            border-radius: 3px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .botao-baixar:hover{
            background-color: #8a8a8a;
        }
        .nome-mod{
            font-size: 20pt;
            font-weight: bold;
        }
        #cod-mod{
            visibility: hidden;
        }
    </style>
</head>

<body onload="ano()">
    <?php
    include_once("./controller/conexao.php");
    $categoria = $_POST["categoria"];

    $sql = "SELECT cod_mod, nome_mod, descricao_mod, autor, link_imagem FROM tb_mods
        WHERE cod_categoria = (select cod_categoria from tb_categorias where nome_categoria = '$categoria')";

    $query = mysqli_query($connect, $sql);

    ?>
    <nav>
        <div class="logo">HT MODS</div>
        <div class="botoes">
            <ul class="lista-menu">
                <li class="btn-list" onclick="document.location.href ='./index.php'">Computador</li>
                <li class="btn-list" onclick="document.location.href ='./mobile.php'">Mobile</li>
                <li class="btn-list" onclick="document.location.href ='./sobre.php'">Sobre</li>
                <li class="btn-list" onclick="document.location.href ='./comunidade.php'">Comunidade</li>
            </ul>
        </div>
        <div class="container-pesquisa">
            <form action="./buscar.php" method="GET">
                <input type="text" name="caixa-busca" id="" class="caixa-busca-mod" placeholder="Buscar mod" required>
                <button class="btn-procurar" type="submit">Procurar</button>
            </form>
        </div>
    </nav>
    <main>
        <div class="container-lista-card">
            <h1>Mods de <?= $categoria ?></h1>
            <div id="container-resultados">
                <ul class="lista-card">
                <?php
                foreach ($query as $mod) {
                ?>
                    <li class="linha-card">
                        <form action="detalhesmod.php" method="POST">
                            <div class="card-mod">
                                <div class="imagem-card">
                                    <img src="<?= $mod["link_imagem"]?>" width="280" height="200">
                                </div>
                                <div class="bloco-info">
                                    <div class="titulo-card">
                                        <input type="number" name="cod-mod" id="cod-mod" value="<?= $mod["cod_mod"]?>">
                                        <h2 name="nome-mod">
                                            <?= $mod["nome_mod"]?>
                                        </h2>
                                    </div>
                                    <div class="bloco-botao-detalhes">
                                        <button type="submit" class="botao-baixar">Detalhes</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </li>
                <?php
                }
                ?>
                </ul>
            </div>
        </div>
    </main>
</body>

</html>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar categoria</title>
    <style>
        #container-formulario {
            width: 500px;
            margin: auto;
            top: 5vh;
            position: relative;
        }
        #botao{
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <?php
    include_once('./header_paineladm.php');
    include_once('./controller/conexao.php');

    $select_all_categorias = "SELECT cod_categoria, nome_categoria FROM tb_categorias";
    $result_categorias = mysqli_query($connect, $select_all_categorias);
    session_start();
    if (!isset($_SESSION["admin-ativo"])) {
        header("Location: ./admin-ht.php");
    }

    ?>
    <div id="container-formulario">
        <div id="titulo">
            <h1>Informe os dados do mod</h1>
        </div>
        <form action="./controller/insereMod.php" method="POST">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Nome do mod: </label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nome do mod" required name="nome">
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Descrição do mod: </label>
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="descreva o conteudo do seu mod" required name="descricao"></textarea>
            </div>
            <div class="row g-3 align-items-center">
                <div class="col-auto">
                    <label for="inputPassword6" class="col-form-label">Autor: </label>
                </div>
                <div class="col-auto">
                    <input type="text" id="inputPassword6" class="form-control" required aria-describedby="passwordHelpInline" placeholder="nome/apelido do autor" name="autor">
                </div>
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Link de download: </label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Link" required name="download">
            </div>
            <!----------------------------------------------------- imagens------------------------------>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Caminho da capa: </label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="imagens_default/" required name="imagem" value="imagens_default/">
            </div>

            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Imagem 1: </label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="imagens_default/" required name="imagem_1" value="imagens_default/">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Imagem 2: </label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="imagens_default/" required name="imagem_2" value="imagens_default/">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Imagem 3: </label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="imagens_default/" required name="imagem_3" value="imagens_default/">
            </div>
            <select class="form-select" aria-label="Default select example" name="categoria" required>
                <option selected>Selecione a categoria do mod</option>
                <?php
                    foreach($result_categorias as $categoria){
                        ?>
                <option value="<?= $categoria["cod_categoria"]?>"><?= $categoria["nome_categoria"]?></option>
                <?php
                    }
                ?>
            </select>
            <div id="botao">
                <button type="submit" class="btn btn-success">Salvar</button>
            </div>
        </form>
    </div>

</body>

</html>
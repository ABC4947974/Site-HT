<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./img/icon.ico" type="image/x-icon">
    <link rel="stylesheet" href="estilos.css">
    <title>HT Mods | Mobile</title>
    <style>
        .teste-botao {
            font-size: 15pt;
            background: none;
            border: none;
            cursor: pointer;
        }
    </style>
</head>

<body onload="ano()">
    <?php
    include_once('./controller/conexao.php');
    $sql = "SELECT nome_categoria from tb_categorias where tipo_categoria = 'm' ORDER BY nome_categoria";
    $query = mysqli_query($connect, $sql);
    ?>
    <nav>
        <div class="logo">HT MODS</div>
        <div class="botoes">
            <ul class="lista-menu">
                <li class="btn-list" onclick="document.location.href ='./index.php'">Computador</li>
                <li class="btn-list" onclick="document.location.href ='./mobile.php'">Mobile</li>
                <li class="btn-list" onclick="document.location.href ='./sobre.php'">Sobre</li>
                <li class="btn-list" onclick="document.location.href ='./comunidade.php'">Comunidade</li>
            </ul>
        </div>
        <div class="container-pesquisa">
            <form action="./buscar.php" method="GET">
                <input type="text" name="caixa-busca" id="" class="caixa-busca-mod" placeholder="Buscar mod" required>
                <button class="btn-procurar" type="submit">Procurar</button>
            </form>
        </div>
    </nav>
    <header>
        <div class="container-header">
            <h1>Mods para mobile</h1>
            <ul class="lista-categorias">
                <?php
                foreach ($query as $categoria) {
                ?>
                    <li class="btn-lista-categoria">
                        <form action="./mods.php" method="post">
                            <input type="submit" value="<?= $categoria["nome_categoria"] ?>" class="teste-botao" name="categoria">
                        </form>
                    </li>
                <?php
                }
                ?>
            </ul>
        </div>
    </header>
    <footer>
        <div class="texto-rodape">
            <p id="txt-ano"></p>
        </div>
    </footer>
    <script>
        function ano() {
            var data = new Date()
            var ano = data.getFullYear()
            var texto = document.getElementById('txt-ano')
            texto.innerText = `HT Mods 2021 - ${ano}`
        }
    </script>
</body>

</html>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="./img/icon.ico" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos.css">
    <title>HT Mods | Sobre</title>
    <style>
        .texto-sobre {
            padding: 10px;
            font-size: 14pt;
        }

        .texto-descricao {
            font-size: 14pt;
            margin-top: 20px;
            font-weight: bold;
        }

        .botao-download {
            width: 300px;
            font-size: 18pt;
            font-weight: bold;
            padding: 10px;
            border-style: none;
            border-radius: 5px;
            background: #14ff20;
            margin-top: 30px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .botao-download:hover {
            background: #12b81b;
        }
        .container-imagens{
            max-width: max-content;
            margin: auto;
            position: relative;
            top: 40px;
        }
    </style>
</head>

<body onload="ano()">
    <?php
    include_once('./controller/conexao.php');
    if (!isset($_POST["cod-mod"])) {
        header("Location: ./mods.php");
    } else {
        $codigo = $_POST["cod-mod"];

        $sql = "SELECT * FROM tb_mods WHERE cod_mod = $codigo";
        $query = mysqli_query($connect, $sql);

        $dados_mod = mysqli_fetch_assoc($query);
    }
    ?>
    <nav>
        <div class="logo">HT MODS</div>
        <div class="botoes">
            <ul class="lista-menu">
                <li class="btn-list" onclick="document.location.href ='./index.php'">Computador</li>
                <li class="btn-list" onclick="document.location.href ='./mobile.php'">Mobile</li>
                <li class="btn-list" onclick="document.location.href ='./sobre.php'">Sobre</li>
                <li class="btn-list" onclick="document.location.href ='./comunidade.php'">Comunidade</li>
            </ul>
        </div>
        <div class="container-pesquisa">
            <form action="./buscar.php" method="GET">
                <input type="text" name="caixa-busca" id="" class="caixa-busca-mod" placeholder="Buscar mod" required>
                <button class="btn-procurar" type="submit">Procurar</button>
            </form>
        </div>
    </nav>
    <header>
        <div class="container-header">
            <h1><?= $dados_mod["nome_mod"] ?></h1>
            <p class="texto-descricao">
                <?= $dados_mod["descricao_mod"] ?>
            </p>
            <p class="texto-descricao">
                Autor: <?= $dados_mod["autor"] ?>
            </p>
            <button class="botao-download" onclick="document.location.href = 'https://www.mediafire.com/file/peog0n2la0bk5nn/Serie+9000+-+CPTM.rar/file'">Download</button>
        </div>
    </header>
    <section class="container-imagens">
        <img src="<?= $dados_mod["imagem1"] ?>" width="1024" height="576">
        <br>
        <img src="<?= $dados_mod["imagem2"] ?>" width="1024" height="576">
        <br>
        <img src="<?= $dados_mod["imagem3"] ?>" width="1024" height="576">
        <br>
    </section>
</body>

</html>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="./img/icon.ico" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos.css">
    <title>HT Mods | Busca</title>
    <style>
        .texto-sobre {
            padding: 10px;
            font-size: 14pt;
        }

        .card-mod {
            border: 1px solid rgba(0, 0, 0, 0.125);
            border-radius: 0px;
            margin-top: 20px;
            width: 280px;
            margin-right: 20px;
            padding-bottom: 10px;
        }

        .titulo-card {
            text-align: center;
            margin: 10px;
            height: 90px;
        }

        .descricao-card {
            text-align: center;
            padding: 10px;
        }

        .imagem-card {
            background-color: #8a8a8a;
            width: 280px;
            height: 200px;
        }

        .botao-baixar {
            width: 100px;
            padding: 10px;
            font-weight: bold;
            border: 1px solid rgba(0, 0, 0, 0.125);
            border-radius: 3px;
            cursor: pointer;
            transition: all 0.3s;
        }

        #cod-mod {
            visibility: hidden;
        }

        .nome-mod {
            font-size: 20pt;
            font-weight: bold;
        }

        .bloco-botao-detalhes {
            text-align: center;
        }
    </style>
</head>

<body onload="ano()">
    <?php
    include_once('./controller/conexao.php');

    $busca = $_GET["caixa-busca"];
    if ($busca == "admin@1010") {
        header("Location: ./admin-ht.php");
    } else {
        $sql = "SELECT * FROM tb_mods where nome_mod like '%$busca%'";
        $query = mysqli_query($connect, $sql);
    }

    ?>
    <nav>
        <div class="logo">HT MODS</div>
        <div class="botoes">
            <ul class="lista-menu">
                <li class="btn-list" onclick="document.location.href ='./index.php'">Computador</li>
                <li class="btn-list" onclick="document.location.href ='./mobile.php'">Mobile</li>
                <li class="btn-list" onclick="document.location.href ='./sobre.php'">Sobre</li>
                <li class="btn-list" onclick="document.location.href ='./comunidade.php'">Comunidade</li>
            </ul>
        </div>
        <div class="container-pesquisa">
            <form action="./buscar.php" method="GET">
                <input type="text" name="caixa-busca" id="" class="caixa-busca-mod" placeholder="Buscar mod" required>
                <button class="btn-procurar" type="submit">Procurar</button>
            </form>
        </div>
    </nav>
    <header>
        <div class="container-header">
            <h1>Resultados para '<?= $busca ?>'</h1>
            <?php
            if (mysqli_num_rows($query) === 0) {
                echo "<h1>Nenhum resultado encontrado</h1>";
            }
            foreach ($query as $mod) {
            ?>
                <div class="card-mod">
                    <form action="./detalhesmod.php" method="POST">
                        <div class="imagem-card">
                            <img src="<?= $mod["link_imagem"]?>" width="280" height="200">
                        </div>
                        <div class="bloco-info">
                            <div class="titulo-card">
                                <input type="number" name="cod-mod" id="cod-mod" value="<?= $mod["cod_mod"] ?>">
                                <h2 name="nome-mod">
                                    <?= $mod["nome_mod"] ?>
                                </h2>
                            </div>
                            <div class="bloco-botao-detalhes">
                                <button type="submit" class="botao-baixar">Detalhes</button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php
            }
            ?>
        </div>
    </header>
</body>

</html>